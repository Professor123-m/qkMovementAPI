import turtle
t = turtle.Turtle()
s = turtle.Screen()



def say(text):
    print(text)

def resolution(width, height):
    s.setup(width, height)
        
def ask(text):
    input(text)
    
def new_line():
    print("")

class move:
    def speed(num):
        t.speed(num)
    def current(dist):
        t.forward(dist)
        
    def right(dist, angle):
        t.right(angle)
        t.forward(dist)
    
    def left(dist, angle):
        t.left(angle)
        t.forward(dist)
        
    def jump(x, y):
        t.penup()
        t.goto(x, y)
        t.pendown()
    
    def hop(dist):
        t.penup()
        t.forward(dist)
        t.pendown()
        
class strafe:
    def right(angle):
        t.right(angle)
    
    def left(angle):
        t.left(angle)
        
class draw: 
    def shape(size, sides):
        angle = ((((sides - 2) * 180)/ sides)- 180)
        
        for x in range(sides):
            t.forward(size)
            t.left(angle)
class fill:
    def colour(text):
        t.fillcolor(text)
    def start():
        t.begin_fill()
    def end():
        t.end_fill()

class pen:
    def colour(text):
        t.pencolor(text)
    def thickness(no):
        t.pensize(no)
    def up():
        t.penup()
    def down():
        t.pendown()
    
        
        
        
    