===qk library README:===
-------------------------------------------------------------------------------------------------------------------------
1. this library is entirely homemade, this is a passion project, my first library.
--------------------------------------------------------------------------------------------------------------------------
2. because it is my first library not everything is perfect, it may have little logic kinks/differences compared to turtle
--------------------------------------------------------------------------------------------------------------------------
3. this library is quicker to right than turtle
--------------------------------------------------------------------------------------------------------------------------
4. I didn't write this library with self and __innit__() kinda stuff, because I don't understand those yet
--------------------------------------------------------------------------------------------------------------------------
5. if you want to make your own branch, feel free to use the source code
--------------------------------------------------------------------------------------------------------------------------


===the classes/types===
-------------------------------------------------------------------------------------------------------------------------------
move := move is the class with all the main movements, with one difference this one moves and turns combined and single forward
-------------------------------------------------------------------------------------------------------------------------------
strafe := this is like move, but without the movement part, only turning
-------------------------------------------------------------------------------------------------------------------------------
fill := this is a class entirely for the fill category like the fill colour and starting and ending fill
-------------------------------------------------------------------------------------------------------------------------------
draw := this class contains only one function, the draw shape function, it can draw any regular shape with any amount of sides
-------------------------------------------------------------------------------------------------------------------------------
pen := this class contains the stuff do with pen, like putting the pen up, down, its thickness and its colour
-------------------------------------------------------------------------------------------------------------------------------

=== move ===

speed = sets the speed of the movement
current = makes you move a certain distance in your current direction 
right = makes you move a certain distance in a certain angle to the right
left = makes you move a certain distance in a certain angle to the left
jump = lets you go to a certain coordinate without getting your pen/lines on the canvas
hop = lets you go a certain distance with the pen up and then puts the pen back down , ready 

=== strafe ===

right = lets you go right a certain angle
left = lets you go left a certain angle

=== draw ===

shape = you enter the amount of sides and size of each side and makes it

=== fill ===

colour = sets the fill colour
start = starts the filling process
end = finishes the filling process

=== pen ===

colour = sets the pen colour
thickness = sets the thickness of pen
up = puts the pen up
down = puts the pen down

=== how you would use them ===

the formatting is like qk.class.function()

so to move forward 100 to the left 90 degrees its qk.move.left(100, 90)

the distance always goes first in the parenthesis 

=== conclusion === 

if you need more info, looking at the source code should reveal the logic




 


